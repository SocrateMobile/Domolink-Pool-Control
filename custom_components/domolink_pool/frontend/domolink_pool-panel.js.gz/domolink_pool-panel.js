/**
 * DomoLink Pool Control - Panneau Latéral Officiel
 * Reproduit la double carte DomoLink Pool Control officielle (Analyse & Contrôle) 
 * et intègre le volet complet de conseils d'entretien & régulation (pH, Chlore, LSI, Filtration).
 */

class DomoLinkPoolControlPanel extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this._view = "analyse"; // "analyse" ou "controle"
    this._initialized = false;
  }

  set panel(panel) {
    this._panel = panel;
  }

  connectedCallback() {
    if (!this._initialized) {
      this._initialized = true;
      this._renderLayout();
    }
    if (this._hass) {
      this._updateData();
    }

    this._sidebarInterval = setInterval(() => {
      this._syncSidebarBadge();
    }, 2500);

    try {
      const ha = document.querySelector("home-assistant");
      const main = ha && ha.shadowRoot && ha.shadowRoot.querySelector("home-assistant-main");
      const sidebar = main && main.shadowRoot && main.shadowRoot.querySelector("ha-sidebar");
      if (sidebar && sidebar.shadowRoot && !this._sidebarObserver) {
        this._sidebarObserver = new MutationObserver(() => {
          this._syncSidebarBadge();
        });
        this._sidebarObserver.observe(sidebar.shadowRoot, { childList: true, subtree: true });
      }
    } catch (e) {}

    this._syncSidebarBadge();
  }

  disconnectedCallback() {
    if (this._sidebarInterval) {
      clearInterval(this._sidebarInterval);
    }
    if (this._sidebarObserver) {
      this._sidebarObserver.disconnect();
      this._sidebarObserver = null;
    }
  }

  set hass(hass) {
    this._hass = hass;
    if (!this._initialized) {
      this._initialized = true;
      this._renderLayout();
    }
    this._updateData();
    this._syncSidebarBadge();
  }

  _syncSidebarBadge() {
    try {
      const ha = document.querySelector("home-assistant");
      const main = ha && ha.shadowRoot && ha.shadowRoot.querySelector("home-assistant-main");
      const sidebar = main && main.shadowRoot && main.shadowRoot.querySelector("ha-sidebar");
      if (!sidebar || !sidebar.shadowRoot) return;

      const integrations = [
        {
          key: "domolink_pool",
          patterns: ["domolink_pool", "domolink_pool-pool", "domolink_pool-pool-control", "domolink_pool"],
          entityIds: ["update.domolink_pool_control", "update.domolink_pool", "update.domolink_pool_mise_a_jour"],
          hasUpdate: undefined,
        },
        {
          key: "domolink_mistral",
          patterns: ["domolink_mistral", "domolink-mistral"],
          entityIds: ["update.domolink_mistralia", "update.domolink_mistral", "update.domolink_mistral_mise_a_jour"],
          hasUpdate: undefined,
        },
        {
          key: "domolink_alarm",
          patterns: ["domolink_alarm", "domolink-alarm"],
          entityIds: ["update.domolink_alarm", "update.domolink_alarm_mise_a_jour"],
          hasUpdate: undefined,
        },
        {
          key: "domolink_backup",
          patterns: ["domolink_backup", "domolink-backup"],
          entityIds: ["update.domolink_backup", "update.domolink_backup_mise_a_jour"],
          hasUpdate: undefined,
        },
      ];

      const container = sidebar.shadowRoot.querySelector("paper-listbox, ha-md-list, nav, div.menu, div.items");
      const items = (container || sidebar.shadowRoot).querySelectorAll("paper-icon-item, ha-md-list-item, ha-sidebar-item, a");

      integrations.forEach((integ) => {
        let isUpdateAvail = integ.hasUpdate;
        if (isUpdateAvail === undefined && this._hass && this._hass.states) {
          isUpdateAvail = integ.entityIds.some((id) => {
            const st = this._hass.states[id];
            return st && (st.state === "on" || (st.attributes && st.attributes.update_available === true));
          });
        }

        for (const item of items) {
          const href = item.getAttribute("href") || (item.dataset && (item.dataset.panel || item.dataset.href)) || "";
          const id = item.id || "";
          const ariaLabel = item.getAttribute("aria-label") || "";
          const text = (item.textContent || "").toLowerCase();

          const isMatch = integ.patterns.some((pat) => {
            const p = pat.toLowerCase();
            return href.toLowerCase().includes(p) ||
                   id.toLowerCase().includes(p) ||
                   ariaLabel.toLowerCase().includes(p.replace(/_/g, " ")) ||
                   (p === "domolink_pool" && text.includes("domolink_pool"));
          });

          if (isMatch) {
            let badge = item.querySelector(".domolink-sidebar-badge");
            if (isUpdateAvail) {
              if (!badge) {
                badge = document.createElement("span");
                badge.className = "badge domolink-sidebar-badge";
                badge.setAttribute("slot", "end");
                badge.style.cssText = "background: linear-gradient(135deg, #ef4444, #f59e0b); color: white; border-radius: 9999px; padding: 2px 7px; font-size: 10px; font-weight: 800; box-shadow: 0 2px 6px rgba(239,68,68,0.4); margin-left: auto; letter-spacing: 0.5px; z-index: 10; display: inline-block;";
                badge.textContent = "MAJ";
                badge.title = "Mise à jour disponible !";
                item.appendChild(badge);
              }
            } else if (badge) {
              badge.remove();
            }
          }
        }
      });
    } catch (e) {
      // Ignore errors
    }
  }

  _renderLayout() {
    this.shadowRoot.innerHTML = `
      <style>
        :host, domolink-pool-panel, domolink_pool-panel {
          background-color: var(--primary-background-color, #f8fafc);
          color: var(--primary-text-color, #1e293b);
          display: block;
          height: 100vh;
          overflow-y: auto;
          box-sizing: border-box;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
          -webkit-font-smoothing: antialiased;
          padding: 16px;
        }

        .domolink_pool-page-container {
          max-width: 1300px;
          margin: 0 auto;
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        .domolink_pool-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px 4px;
        }

        .domolink_pool-title-group {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .domolink_pool-app-icon {
          width: 44px;
          height: 44px;
          border-radius: 12px;
          background: linear-gradient(135deg, #0284c7, #0369a1);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 24px;
          box-shadow: 0 4px 12px rgba(2, 132, 199, 0.35);
        }

        .domolink_pool-title {
          font-size: 24px;
          font-weight: 700;
          color: var(--primary-text-color, #1e293b);
          margin: 0;
        }

        .domolink_pool-subtitle {
          font-size: 13px;
          color: var(--secondary-text-color, #64748b);
          margin-top: 2px;
        }

        .domolink_pool-refresh-btn {
          background: var(--ha-card-background, var(--card-background-color, #ffffff));
          border: 1px solid var(--divider-color, rgba(0,0,0,0.12));
          color: var(--primary-text-color, #1e293b);
          padding: 8px 16px;
          border-radius: 10px;
          cursor: pointer;
          font-size: 13px;
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 6px;
          box-shadow: 0 2px 6px rgba(0,0,0,0.04);
          transition: all 0.2s ease;
        }

        .domolink_pool-refresh-btn:hover {
          background: #0284c7;
          color: white;
          border-color: #0284c7;
        }

        /* Grille principale : Carte DomoLink Pool Control à gauche, Conseils à droite */
        .domolink_pool-main-grid {
          display: grid;
          grid-template-columns: minmax(360px, 440px) 1fr;
          gap: 24px;
          align-items: start;
        }

        @media (max-width: 900px) {
          .domolink_pool-main-grid {
            grid-template-columns: 1fr;
          }
        }

        /* --- CARTE FLIPR REPRODUITE --- */
        .domolink_pool-card-frame {
          background: #eef4f8;
          border-radius: 32px;
          box-shadow: 0 16px 36px rgba(0,0,0,0.25);
          overflow: hidden;
          color: #1e293b;
          display: flex;
          flex-direction: column;
          min-height: 720px;
        }

        .card-header-bar {
          padding: 18px 20px 8px 20px;
          text-align: center;
        }

        .pool-location-selector {
          font-size: 15px;
          font-weight: 600;
          color: #1e293b;
          margin-bottom: 14px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
        }

        .tabs-pill-container {
          display: flex;
          background: #94a3b8;
          border-radius: 16px;
          padding: 3px;
          width: 100%;
          box-sizing: border-box;
        }

        .tab-btn {
          flex: 1;
          padding: 8px 12px;
          border-radius: 13px;
          font-size: 14px;
          font-weight: 500;
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          cursor: pointer;
          transition: all 0.2s ease;
          border: none;
          background: transparent;
        }

        .tab-btn.active {
          background: #1e293b;
          font-weight: 700;
          box-shadow: 0 3px 8px rgba(0,0,0,0.2);
        }

        .card-body {
          padding: 12px 20px 16px 20px;
          flex-grow: 1;
          display: flex;
          flex-direction: column;
          gap: 14px;
        }

        .air-meteo-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 4px;
        }

        .air-temp-display {
          display: flex;
          align-items: baseline;
          gap: 6px;
        }

        .air-label {
          font-size: 18px;
          color: #64748b;
          font-weight: 400;
        }

        .air-value {
          font-size: 44px;
          font-weight: 800;
          color: #1e293b;
          letter-spacing: -1px;
        }

        .air-trend {
          color: #0284c7;
          font-weight: 800;
          font-size: 18px;
        }

        .uv-badge-box {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
        }

        .uv-pill {
          border: 1.5px solid #64748b;
          border-radius: 12px;
          padding: 2px 10px;
          font-size: 11px;
          font-weight: 700;
          color: #334155;
        }

        .card-subblock {
          background: white;
          border-radius: 18px;
          padding: 12px 14px;
          box-shadow: 0 4px 14px rgba(0,0,0,0.03);
        }

        /* Vue Analyse : Pompe + Météo combo */
        .combo-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 10px;
        }

        .pump-quick-card {
          background: white;
          border-radius: 18px;
          padding: 12px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          box-shadow: 0 4px 14px rgba(0,0,0,0.03);
        }

        .pump-btn-icon {
          width: 32px;
          height: 32px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 15px;
          font-weight: bold;
          cursor: pointer;
          transition: transform 0.15s ease;
          border: none;
        }

        .pump-btn-icon:hover {
          transform: scale(1.08);
        }

        .pump-on {
          background: #22c55e;
          color: white;
          box-shadow: 0 2px 10px rgba(34,197,94,0.4);
        }

        .pump-off {
          background: #f1f5f9;
          color: #94a3b8;
        }

        /* Vue Contrôle : Barre complète de contrôle pompe */
        .pump-control-full {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .pump-actions-group {
          display: flex;
          gap: 8px;
        }

        .pump-circle-action {
          background: #f1f5f9;
          color: #94a3b8;
          width: 38px;
          height: 38px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
          cursor: pointer;
          border: none;
          transition: all 0.2s ease;
        }

        .pump-circle-action:hover {
          background: #e2e8f0;
          color: #1e293b;
        }

        /* 7-Day History Bars */
        .history-section {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .history-title {
          font-size: 11px;
          color: #475569;
          font-weight: 700;
        }

        .history-days-row {
          display: flex;
          justify-content: space-between;
          gap: 4px;
          text-align: center;
        }

        .history-day-item {
          flex: 1;
        }

        .history-day-pill {
          border: 1px solid #cbd5e1;
          border-radius: 6px;
          padding: 3px 1px;
          font-size: 10px;
          color: #64748b;
          font-weight: 600;
          background: white;
        }

        .history-day-pill.current {
          background: #0284c7;
          border-color: #0284c7;
          color: white;
          font-weight: 700;
        }

        .history-day-date {
          font-size: 9px;
          color: #94a3b8;
          margin-top: 3px;
        }

        /* Bas Dégradé DomoLink Pool Control */
        .domolink_pool-bottom-gradient {
          background: linear-gradient(170deg, #10b981 0%, #0284c7 40%, #1e3a8a 100%);
          border-top-left-radius: 36px;
          border-top-right-radius: 36px;
          padding: 24px 20px 16px 20px;
          color: white;
          display: flex;
          flex-direction: column;
          gap: 18px;
          justify-content: space-between;
          margin-top: auto;
        }

        .water-header-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .water-temp-big {
          font-size: 44px;
          font-weight: 800;
          letter-spacing: -1px;
        }

        .gauges-container {
          display: flex;
          justify-content: space-around;
          align-items: flex-end;
          margin: 6px 0;
        }

        .gauge-item {
          text-align: center;
          flex: 1;
        }

        .gauge-svg-wrap {
          position: relative;
          width: 106px;
          height: 106px;
          margin: 0 auto;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .gauge-center-text {
          position: absolute;
          font-size: 24px;
          font-weight: 700;
        }

        .status-pill-badge {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 5px;
          margin-top: 8px;
          padding: 4px 14px;
          border: 1.5px solid rgba(255, 255, 255, 0.4);
          border-radius: 20px;
          font-size: 12px;
          font-weight: 700;
          background: rgba(255, 255, 255, 0.15);
          color: white;
          white-space: nowrap;
          transition: all 0.3s ease;
          box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }

        .status-pill-badge.pill-ok {
          background: rgba(16, 185, 129, 0.3);
          border-color: #6ee7b7;
          color: #ffffff;
        }

        .status-pill-badge.pill-warn {
          background: rgba(245, 158, 11, 0.35);
          border-color: #fcd34d;
          color: #ffffff;
        }

        .status-pill-badge.pill-danger {
          background: rgba(239, 68, 68, 0.4);
          border-color: #fca5a5;
          color: #ffffff;
        }

        .status-pill-badge.pill-wait {
          background: rgba(255, 255, 255, 0.12);
          border-color: rgba(255, 255, 255, 0.35);
          color: #e2e8f0;
        }

        .card-footer-nav {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding-top: 10px;
          font-size: 11px;
          font-weight: 500;
        }

        .dolphin-btn {
          border: 1.5px solid white;
          border-radius: 50%;
          width: 44px;
          height: 44px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 20px;
          background: rgba(255,255,255,0.1);
        }

        /* --- VOLET CONSEILS D'ENTRETIEN & RÉGULATION --- */
        .advice-panel-column {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .advice-card {
          background: var(--ha-card-background, var(--card-background-color, #ffffff));
          border-radius: 24px;
          padding: 20px;
          border: 1px solid var(--divider-color, rgba(0,0,0,0.08));
          box-shadow: 0 4px 16px rgba(0,0,0,0.05);
          color: var(--primary-text-color, #1e293b);
        }

        .advice-card-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 16px;
        }

        .advice-card-title {
          font-size: 17px;
          font-weight: 700;
          display: flex;
          align-items: center;
          gap: 10px;
          color: var(--primary-text-color, #1e293b);
        }

        .badge-status-tag {
          font-size: 11px;
          font-weight: 700;
          padding: 4px 10px;
          border-radius: 8px;
          text-transform: uppercase;
        }

        .tag-ok { 
          background: rgba(34, 197, 94, 0.15); 
          color: #16a34a; 
          border: 1px solid rgba(34, 197, 94, 0.35); 
        }
        .tag-warn { 
          background: rgba(245, 158, 11, 0.15); 
          color: #d97706; 
          border: 1px solid rgba(245, 158, 11, 0.35); 
        }
        .tag-danger { 
          background: rgba(239, 68, 68, 0.15); 
          color: #dc2626; 
          border: 1px solid rgba(239, 68, 68, 0.35); 
        }
        .tag-info { 
          background: rgba(2, 132, 199, 0.15); 
          color: #0284c7; 
          border: 1px solid rgba(2, 132, 199, 0.35); 
        }

        .advice-metric-row {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
          gap: 12px;
          margin-bottom: 14px;
        }

        .metric-box {
          background: var(--secondary-background-color, rgba(125, 125, 125, 0.05));
          border: 1px solid var(--divider-color, rgba(125, 125, 125, 0.15));
          border-radius: 14px;
          padding: 12px;
          text-align: center;
        }

        .metric-label {
          font-size: 11px;
          color: var(--secondary-text-color, #64748b);
          font-weight: 600;
          margin-bottom: 4px;
        }

        .metric-val {
          font-size: 20px;
          font-weight: 800;
          color: var(--primary-text-color, #1e293b);
        }

        .metric-target {
          font-size: 10px;
          color: var(--secondary-text-color, #64748b);
          font-weight: 500;
          margin-top: 3px;
        }

        .advice-action-box {
          background: rgba(2, 132, 199, 0.09);
          border-left: 4px solid #0284c7;
          border-radius: 0 12px 12px 0;
          padding: 12px 14px;
          font-size: 13px;
          line-height: 1.55;
          color: var(--primary-text-color, #1e293b);
          font-weight: 500;
          display: flex;
          gap: 10px;
          align-items: flex-start;
        }

        .action-icon {
          font-size: 18px;
          flex-shrink: 0;
        }

        .dose-highlight {
          font-weight: 800;
          color: #0284c7;
        }

        .lsi-bar-wrapper {
          margin: 14px 0 8px 0;
        }

        .lsi-gradient-bar {
          height: 10px;
          border-radius: 5px;
          background: linear-gradient(to right, #ef4444 0%, #eab308 30%, #22c55e 50%, #eab308 70%, #ef4444 100%);
          position: relative;
        }

        .lsi-cursor {
          position: absolute;
          top: -4px;
          width: 6px;
          height: 18px;
          background: white;
          border-radius: 3px;
          box-shadow: 0 0 6px rgba(0,0,0,0.8);
          transform: translateX(-50%);
        }

        .lsi-labels-row {
          display: flex;
          justify-content: space-between;
          font-size: 10px;
          color: var(--secondary-text-color, #64748b);
          font-weight: 600;
          margin-top: 4px;
        }

        /* Support Spécifique Mode Sombre (Dark Theme) */
        @media (prefers-color-scheme: dark) {
          .tag-ok { color: #4ade80; }
          .tag-warn { color: #fbbf24; }
          .tag-danger { color: #f87171; }
          .tag-info { color: #38bdf8; }
          .dose-highlight { color: #38bdf8; }
          .advice-action-box { background: rgba(2, 132, 199, 0.16); }
        }
      </style>

      <div class="domolink_pool-page-container">
        <!-- HEADER -->
        <div class="domolink_pool-header">
          <div class="domolink_pool-title-group">
            <div class="domolink_pool-app-icon">🐬</div>
            <div>
              <h1 class="domolink_pool-title">DomoLink Pool Control</h1>
              <div class="domolink_pool-subtitle" id="last-sync-time">Synchronisation en direct</div>
            </div>
          </div>
          <button class="domolink_pool-refresh-btn" id="btn-force-sync">
            <span>🔄</span> Forcer actualisation
          </button>
        </div>

        <!-- MAIN GRID -->
        <div class="domolink_pool-main-grid">
          <!-- GAUCHE : CARTE OFFICIELLE FLIPR -->
          <div class="domolink_pool-card-frame" id="domolink_pool-card-content">
            <!-- Rendu dynamique ici -->
          </div>

          <!-- DROITE : CONSEILS D'ENTRETIEN & TRAITEMENTS -->
          <div class="advice-panel-column" id="advice-content">
            <!-- Rendu dynamique des conseils ici -->
          </div>
        </div>
      </div>
    `;

    this.shadowRoot.querySelector("#btn-force-sync")?.addEventListener("click", () => {
      if (this._hass) {
        this._hass.callService("domolink_pool", "force_cloud_sync", {});
      }
    });

    const poolTitle = this.shadowRoot.querySelector(".domolink_pool-title");
    if (poolTitle) {
      poolTitle.style.cursor = "pointer";
      let titleClicks = [];
      poolTitle.addEventListener("click", () => {
        const now = Date.now();
        titleClicks = titleClicks.filter((t) => now - t < 2000);
        titleClicks.push(now);
        if (titleClicks.length >= 3) {
          titleClicks = [];
          launchSocrateRulesEasterEgg(this.shadowRoot);
        }
      });
    }
  }

  _extractData() {
    if (!this._hass) return {};
    const states = this._hass.states;

    // Détection automatique du préfixe des entités
    const ph_entity_key = Object.keys(states).find(
      (e) => e.startsWith("sensor.") && e.includes("domolink_pool") && e.endsWith("_ph")
    );
    const prefix = ph_entity_key ? ph_entity_key.replace("_ph", "") : "sensor.domolink_pool";

    const getVal = (suffixes, def = "0") => {
      const list = Array.isArray(suffixes) ? suffixes : [suffixes];
      for (const suffix of list) {
        const e = states[`${prefix}_${suffix}`];
        if (e && e.state !== undefined && e.state !== "unavailable" && e.state !== "unknown") {
          return e.state;
        }
      }
      return def;
    };

    const getFullEntity = (pred) => {
      const k = Object.keys(states).find(pred);
      return k && states[k] ? states[k].state : null;
    };

    // Pompe de filtration : switch configuré dans l'intégration ou détection automatique
    const all_keys = Object.keys(states);
    const domolink_keys = all_keys.filter((e) => e.includes("domolink_pool"));
    const configured_pump = (domolink_keys.find(e => e.endsWith("_pump_entity")) && states[domolink_keys.find(e => e.endsWith("_pump_entity"))]?.state) || null;
    const pump_entity_key = (configured_pump && states[configured_pump]) ? configured_pump : Object.keys(states).find(
      (e) => e.startsWith("switch.") && !e.includes("scanner") && !e.includes("ble") && (
        e.includes("pompe_filtration") || e.includes("pump_filtration") || e.includes("pompe") || e.includes("pump") || e.includes("filtration") || e.includes("domolink_pool_hub")
      )
    ) || Object.keys(states).find(
      (e) => e.startsWith("switch.") && !e.includes("scanner") && !e.includes("ble") && (
        (prefix && e.startsWith(prefix.replace("sensor.", "switch.")))
      )
    );
    const pump_state = pump_entity_key && states[pump_entity_key] ? states[pump_entity_key].state : "off";

    const ph_val = getVal("ph", "7.2");
    const redox_val = getVal(["potentiel_redox", "redox"], "650");

    // Calcul contextuel dynamique du badge pH
    const ph_num = parseFloat(ph_val);
    let ph_status = "Idéal";
    let ph_badge_icon = "👍";
    let ph_badge_class = "pill-ok";

    if (isNaN(ph_num)) {
      ph_status = "En attente";
      ph_badge_icon = "⏳";
      ph_badge_class = "pill-wait";
    } else if (ph_num >= 7.0 && ph_num <= 7.4) {
      ph_status = "Idéal";
      ph_badge_icon = "👍";
      ph_badge_class = "pill-ok";
    } else if (ph_num > 7.4 && ph_num <= 7.7) {
      ph_status = "Élevé";
      ph_badge_icon = "⚠️";
      ph_badge_class = "pill-warn";
    } else if (ph_num > 7.7) {
      ph_status = "Trop haut";
      ph_badge_icon = "🚨";
      ph_badge_class = "pill-danger";
    } else if (ph_num >= 6.8 && ph_num < 7.0) {
      ph_status = "Un peu bas";
      ph_badge_icon = "⚠️";
      ph_badge_class = "pill-warn";
    } else {
      ph_status = "Trop bas";
      ph_badge_icon = "🚨";
      ph_badge_class = "pill-danger";
    }

    // Calcul contextuel dynamique du badge Chlore / Redox
    const rx_num = parseFloat(redox_val);
    let cl_status = "Idéal";
    let cl_badge_icon = "👍";
    let cl_badge_class = "pill-ok";

    if (isNaN(rx_num)) {
      cl_status = "En attente";
      cl_badge_icon = "⏳";
      cl_badge_class = "pill-wait";
    } else if (rx_num >= 650 && rx_num <= 750) {
      cl_status = "Idéal";
      cl_badge_icon = "👍";
      cl_badge_class = "pill-ok";
    } else if (rx_num > 750 && rx_num <= 800) {
      cl_status = "Élevé";
      cl_badge_icon = "⚠️";
      cl_badge_class = "pill-warn";
    } else if (rx_num > 800) {
      cl_status = "Surdosage";
      cl_badge_icon = "🚨";
      cl_badge_class = "pill-danger";
    } else if (rx_num >= 580 && rx_num < 650) {
      cl_status = "Faible";
      cl_badge_icon = "⚠️";
      cl_badge_class = "pill-warn";
    } else {
      cl_status = "Insuffisant";
      cl_badge_icon = "🚨";
      cl_badge_class = "pill-danger";
    }

    return {
      prefix,
      pump_entity_key,
      pump_state,
      air_temp: getVal(["temperature_de_l_air", "air_temp", "air_temperature"], "32"),
      uv_index: getVal(["indice_uv", "uv_index"], "0"),
      water_temp: getVal(["temperature_de_l_eau", "temperature", "water_temp", "water_temperature"], "28"),
      ph_val,
      ph_status,
      ph_badge_icon,
      ph_badge_class,
      redox_val,
      cl_status,
      cl_badge_icon,
      cl_badge_class,
      last_measure: getVal(["derniere_mesure", "last_update", "last_measurement"], "Aujourd'hui"),
      advice_filtration: getVal(["conseil_de_filtration", "conseil_filtration", "temps_de_filtration_recommande", "filtration_advice", "pump_hours"], "Filtrer 12h / jour"),
      ph_minus_dose: parseFloat(getVal(["dose_ph_moins", "dose_ph", "dose_ph_minus", "ph_minus_dose"], "0")) || 0,
      ph_plus_dose: parseFloat(getVal(["dose_ph_plus", "dose_ph_2", "ph_plus_dose"], "0")) || 0,
      cl_shock_dose: parseFloat(getVal(["dose_chlore_choc", "dose_cl_shock", "cl_shock_dose"], "0")) || 0,
      cl_maint_dose: parseFloat(getVal(["dose_chlore_entretien", "dose_cl_maint", "cl_maint_dose"], "0")) || 0,
      lsi_val: parseFloat(getVal(["indice_de_saturation_lsi", "isl", "lsi", "indice_lsi"], "0.0")) || 0.0,
      lsi_status: getVal(["etat_de_l_eau", "etat_de_l_eau_lsi", "lsi_status", "statut_lsi"]) || getFullEntity((k) => k.includes("domolink_pool") && (k.endsWith("_etat_de_l_eau") || k.endsWith("_etat_de_l_eau_lsi") || k.endsWith("_statut_isl") || k.endsWith("_statut_lsi") || k.endsWith("_lsi_status"))) || "Eau équilibrée",
      free_cl: getVal(["chlore_libre", "free_chlorine"], "1.5"),
      active_cl: getVal(["chlore_actif_reel_hocl", "chlore_actif", "active_chlorine"], "0.6"),
      battery: getVal(["batterie", "battery", "battery_level"], "100"),
      pool_name: states[ph_entity_key] ? states[ph_entity_key].attributes?.friendly_name?.replace(/ pH$/i, "").replace(/^DomoLink Pool /i, "") || "Piscine" : "Piscine",
    };
  }

  _formatDate(dateStr) {
    if (!dateStr || dateStr === "Aujourd'hui" || dateStr === "Inconnu" || dateStr === "unavailable" || dateStr === "unknown") {
      return dateStr || "Inconnu";
    }

    const months = [
      "Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
      "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"
    ];

    // Regex d'extraction directe (gère ISO 8601 YYYY-MM-DDTHH:MM...)
    const match = String(dateStr).match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})/);
    if (match) {
      const year = match[1];
      const monthIdx = parseInt(match[2], 10) - 1;
      const day = parseInt(match[3], 10);
      const hours = match[4];
      const minutes = match[5];
      const monthName = months[monthIdx] || match[2];
      return `${day} ${monthName} ${year} à ${hours}H${minutes}`;
    }

    // Fallback avec l'objet Date JavaScript
    try {
      const dt = new Date(dateStr);
      if (!isNaN(dt.getTime())) {
        const day = dt.getDate();
        const month = months[dt.getMonth()];
        const year = dt.getFullYear();
        const hours = String(dt.getHours()).padStart(2, "0");
        const minutes = String(dt.getMinutes()).padStart(2, "0");
        return `${day} ${month} ${year} à ${hours}H${minutes}`;
      }
    } catch (e) {}

    return dateStr;
  }

  _updateData() {
    try {
      const d = this._extractData();
      const cardEl = this.shadowRoot?.querySelector("#domolink_pool-card-content");
      const adviceEl = this.shadowRoot?.querySelector("#advice-content");
      const syncTimeEl = this.shadowRoot?.querySelector("#last-sync-time");

      if (syncTimeEl) {
        const formattedDate = this._formatDate(d.last_measure);
        const battNum = parseFloat(d.battery);
        const battStr = isNaN(battNum) ? `${d.battery}%` : (d.battery.includes('.') ? `${d.battery}%` : `${battNum.toFixed(1)}%`);
        syncTimeEl.textContent = `Dernière mesure : ${formattedDate} • Batterie : ${battStr}`;
      }

      if (cardEl) {
        cardEl.innerHTML = this._view === "analyse" ? this._renderAnalyseCard(d) : this._renderControleCard(d);
        this._bindCardEvents(cardEl, d);
      }

      if (adviceEl) {
        adviceEl.innerHTML = this._renderAdviceSection(d);
      }
    } catch (err) {
      console.error("DomoLink Pool Control: Erreur lors de la mise à jour des données :", err);
    }
  }

  _renderAnalyseCard(d) {
    // Calcul Knob pH
    const ph_num = parseFloat(d.ph_val) || 7.2;
    let ph_pct = Math.max(0, Math.min(1, (ph_num - 6.4) / (8.0 - 6.4)));
    const ph_angle = (135 + ph_pct * 270) * (Math.PI / 180);
    const ph_x = 50 + 42 * Math.cos(ph_angle);
    const ph_y = 50 + 42 * Math.sin(ph_angle);

    // Calcul Knob Redox
    const rx_num = parseFloat(d.redox_val) || 650;
    let rx_pct = Math.max(0, Math.min(1, (rx_num - 465) / (965 - 465)));
    const rx_angle = (135 + rx_pct * 270) * (Math.PI / 180);
    const rx_x = 50 + 42 * Math.cos(rx_angle);
    const rx_y = 50 + 42 * Math.sin(rx_angle);

    const pumpClass = d.pump_state === "on" ? "pump-on" : "pump-off";

    return `
      <!-- EN-TETE & ONGLETS -->
      <div class="card-header-bar">
        <div class="pool-location-selector">
          ${d.pool_name} <span style="font-size: 10px; color: #64748b;">▼</span>
        </div>
        <div class="tabs-pill-container">
          <button class="tab-btn active" id="tab-btn-analyse">💧 Analyse</button>
          <button class="tab-btn" id="tab-btn-controle">🔲 Contrôle</button>
        </div>
      </div>

      <!-- CORPS ANALYSE -->
      <div class="card-body">
        <!-- Air & Météo -->
        <div class="air-meteo-row">
          <div class="air-temp-display">
            <span class="air-label">air</span>
            <span class="air-value">${d.air_temp}°C</span>
            <span class="air-trend">↘</span>
          </div>
          <div style="height: 32px; width: 1px; background: #cbd5e1;"></div>
          <div class="uv-badge-box">
            <div style="font-size: 16px; color: #475569;">☀️ <span style="font-size: 12px; color: #94a3b8;">&gt;</span> ☁️</div>
            <div class="uv-pill">UV ${d.uv_index}</div>
          </div>
        </div>

        <!-- Combo Pompe & Probabilité météo -->
        <div class="combo-row">
          <div class="pump-quick-card">
            <div style="display: flex; align-items: center; gap: 8px;">
              <div style="font-size: 24px;">⚙️</div>
              <div style="font-size: 11px; font-weight: 700; color: #475569; line-height: 1.2;">Pompe Filtration</div>
            </div>
            <button class="pump-btn-icon ${pumpClass}" id="btn-toggle-pump">⏻</button>
          </div>

          <div class="card-subblock" style="display: flex; flex-direction: column; justify-content: center;">
            <div style="font-size: 8px; font-weight: 700; color: #94a3b8; text-transform: uppercase; text-align: center; margin-bottom: 4px;">Probabilité dans les 5h</div>
            <div style="display: flex; justify-content: space-around; align-items: center;">
              <div style="text-align: center;">
                <div style="font-size: 14px;">🌧️</div>
                <div style="font-size: 11px; font-weight: 700; color: #475569;">0%</div>
              </div>
              <div style="height: 20px; width: 1px; background: #e2e8f0;"></div>
              <div style="text-align: center;">
                <div style="font-size: 14px;">💨</div>
                <div style="font-size: 11px; font-weight: 700; color: #475569;">10km/h</div>
              </div>
            </div>
          </div>
        </div>

        <!-- Dernière Mesure -->
        <div class="card-subblock" style="display: flex; align-items: center; justify-content: space-between;">
          <div style="display: flex; align-items: center; gap: 12px;">
            <div style="background: #ff2d75; color: white; width: 38px; height: 38px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 20px;">
              📡
            </div>
            <div>
              <div style="font-size: 14px; font-weight: 700; color: #0f172a;">Dernière Mesure</div>
              <div style="font-size: 12px; color: #64748b; font-weight: 400; margin-top: 1px;">${this._formatDate(d.last_measure)}</div>
            </div>
          </div>
          <div style="background: #f1f5f9; width: 34px; height: 34px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 16px; color: #64748b;">
            ⚙️
          </div>
        </div>

        <!-- Conseils & Actions rapides -->
        <div class="card-subblock" style="display: flex; flex-direction: column; gap: 6px;">
          <div style="font-size: 12px; font-weight: 700; color: #1e293b; margin-bottom: 2px;">Conseils & Actions</div>
          <div style="display: flex; align-items: center; gap: 8px;">
            <div style="font-size: 15px;">⏱️</div>
            <div style="font-size: 12px; font-weight: 500; color: #475569;">${d.advice_filtration}</div>
          </div>
          ${
            d.ph_minus_dose > 0
              ? `<div style="display: flex; align-items: center; gap: 8px; font-size: 12px; font-weight: 600; color: #ef4444;">
                  <span>🧪</span> Ajouter ${d.ph_minus_dose}g de pH-
                </div>`
              : ""
          }
          ${
            d.ph_plus_dose > 0
              ? `<div style="display: flex; align-items: center; gap: 8px; font-size: 12px; font-weight: 600; color: #3b82f6;">
                  <span>🧪</span> Ajouter ${d.ph_plus_dose}g de pH+
                </div>`
              : ""
          }
          ${
            d.ph_minus_dose === 0 && d.ph_plus_dose === 0 && d.cl_shock_dose === 0
              ? `<div style="display: flex; align-items: center; gap: 8px; font-size: 12px; font-weight: 600; color: #10b981;">
                  <span>✨</span> Chimie équilibrée, aucune action requise.
                </div>`
              : ""
          }
        </div>
      </div>

      <!-- BAS DEGRADE AVEC JAUGES -->
      <div class="domolink_pool-bottom-gradient">
        <div class="water-header-row">
          <div style="display: flex; align-items: baseline; gap: 8px;">
            <span style="font-size: 18px; font-weight: 400; opacity: 0.9;">eau</span>
            <span class="water-temp-big">${d.water_temp}°C</span>
          </div>
          <div style="background: rgba(255,255,255,0.2); border-radius: 12px; width: 38px; height: 38px; display: flex; align-items: center; justify-content: center; font-size: 16px; border: 1px solid rgba(255,255,255,0.3);">
            🔗
          </div>
        </div>

        <!-- Jauges pH et Chlore -->
        <div class="gauges-container">
          <!-- JAUGE pH -->
          <div class="gauge-item">
            <div class="gauge-svg-wrap">
              <svg width="100" height="100" viewBox="0 0 100 100">
                <defs>
                  <linearGradient id="phGrad" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="0" y2="100">
                    <stop offset="0%" stop-color="#10b981" />
                    <stop offset="20%" stop-color="#eab308" />
                    <stop offset="60%" stop-color="#ef4444" />
                  </linearGradient>
                </defs>
                <path d="M 20.3 79.7 A 42 42 0 1 1 79.7 79.7" stroke="url(#phGrad)" stroke-width="8" stroke-linecap="round" fill="none" opacity="0.9" />
                <circle cx="${ph_x}" cy="${ph_y}" r="6" fill="#ffffff" stroke="rgba(0,0,0,0.2)" stroke-width="2" />
              </svg>
              <div class="gauge-center-text">${d.ph_val}</div>
            </div>
            <div style="font-size: 14px; font-weight: 600; margin-top: 6px;">pH</div>
            <div class="status-pill-badge ${d.ph_badge_class}">${d.ph_badge_icon} ${d.ph_status}</div>
          </div>

          <!-- JAUGE CHLORE / REDOX -->
          <div class="gauge-item">
            <div class="gauge-svg-wrap">
              <svg width="100" height="100" viewBox="0 0 100 100">
                <defs>
                  <linearGradient id="rxGrad" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="0" y2="100">
                    <stop offset="0%" stop-color="#10b981" />
                    <stop offset="20%" stop-color="#eab308" />
                    <stop offset="60%" stop-color="#ef4444" />
                  </linearGradient>
                </defs>
                <path d="M 20.3 79.7 A 42 42 0 1 1 79.7 79.7" stroke="url(#rxGrad)" stroke-width="8" stroke-linecap="round" fill="none" opacity="0.9" />
                <circle cx="${rx_x}" cy="${rx_y}" r="6" fill="#ffffff" stroke="rgba(0,0,0,0.2)" stroke-width="2" />
              </svg>
              <div class="gauge-center-text">${d.redox_val}</div>
            </div>
            <div style="font-size: 14px; font-weight: 600; margin-top: 6px;">Chlore</div>
            <div class="status-pill-badge ${d.cl_badge_class}">${d.cl_badge_icon} ${d.cl_status}</div>
          </div>
        </div>

        <!-- Pied de carte -->
        <div class="card-footer-nav">
          <div style="text-align: center;">
            <div style="font-size: 18px;">〰️</div>
            <div>Menu</div>
          </div>
          <div class="dolphin-btn">🐬</div>
          <div style="text-align: center;">
            <div style="font-size: 18px;">🪣</div>
            <div>DomoLink Pool Control Store</div>
          </div>
        </div>
      </div>
    `;
  }

  _renderControleCard(d) {
    const pumpClass = d.pump_state === "on" ? "pump-on" : "pump-off";

    return `
      <!-- EN-TETE & ONGLETS -->
      <div class="card-header-bar">
        <div class="pool-location-selector">
          ${d.pool_name} <span style="font-size: 10px; color: #64748b;">▼</span>
        </div>
        <div class="tabs-pill-container">
          <button class="tab-btn" id="tab-btn-analyse">💧 Analyse</button>
          <button class="tab-btn active" id="tab-btn-controle">🔲 Contrôle</button>
        </div>
      </div>

      <!-- CORPS CONTROLE -->
      <div class="card-body">
        <!-- Air & Météo -->
        <div class="air-meteo-row">
          <div class="air-temp-display">
            <span class="air-label">air</span>
            <span class="air-value">${d.air_temp}°C</span>
            <span class="air-trend">↘</span>
          </div>
          <div style="height: 32px; width: 1px; background: #cbd5e1;"></div>
          <div class="uv-badge-box">
            <div style="font-size: 16px; color: #475569;">☀️ <span style="font-size: 12px; color: #94a3b8;">&gt;</span> ☁️</div>
            <div class="uv-pill">UV ${d.uv_index}</div>
          </div>
        </div>

        <!-- Barre de Contrôle Pompe Complète -->
        <div class="card-subblock pump-control-full">
          <div style="display: flex; flex-direction: column; gap: 4px;">
            <div style="font-size: 24px; line-height: 1;">🚰</div>
            <div style="font-size: 12px; font-weight: 700; color: #1e293b;">Pompe à filtration</div>
          </div>
          <div class="pump-actions-group">
            <button class="pump-circle-action" title="Mode Automatique">⚡ᴬ</button>
            <button class="pump-circle-action" title="Minuteur">⏱️</button>
            <button class="pump-circle-action ${pumpClass}" id="btn-toggle-pump" style="font-weight: bold;" title="Marche/Arrêt">⏻</button>
            <button class="pump-circle-action" title="Réglages">⚙️</button>
          </div>
        </div>

        <!-- Historique pH 7 jours -->
        <div class="card-subblock history-section">
          <div class="history-title">Taux de pH sur les 7 derniers jours</div>
          <div class="history-days-row">
            <div class="history-day-item"><div class="history-day-pill">7.8 ↘</div><div class="history-day-date">J-6</div></div>
            <div class="history-day-item"><div class="history-day-pill">7.7 ↘</div><div class="history-day-date">J-5</div></div>
            <div class="history-day-item"><div class="history-day-pill">7.8 ↗</div><div class="history-day-date">J-4</div></div>
            <div class="history-day-item"><div class="history-day-pill">7.8 ↗</div><div class="history-day-date">J-3</div></div>
            <div class="history-day-item"><div class="history-day-pill">7.6 ↘</div><div class="history-day-date">J-2</div></div>
            <div class="history-day-item"><div class="history-day-pill">7.3 ↘</div><div class="history-day-date">Hier</div></div>
            <div class="history-day-item"><div class="history-day-pill current">${d.ph_val}</div><div class="history-day-date">Auj.</div></div>
          </div>
        </div>

        <!-- Historique Redox 7 jours -->
        <div class="card-subblock history-section">
          <div class="history-title">Taux de Redox(mV) sur les 7 derniers jours</div>
          <div class="history-days-row">
            <div class="history-day-item"><div class="history-day-pill">628 ↘</div><div class="history-day-date">J-6</div></div>
            <div class="history-day-item"><div class="history-day-pill">577 ↘</div><div class="history-day-date">J-5</div></div>
            <div class="history-day-item"><div class="history-day-pill">533 ↗</div><div class="history-day-date">J-4</div></div>
            <div class="history-day-item"><div class="history-day-pill">537 ↘</div><div class="history-day-date">J-3</div></div>
            <div class="history-day-item"><div class="history-day-pill">516 ↘</div><div class="history-day-date">J-2</div></div>
            <div class="history-day-item"><div class="history-day-pill">580 ↗</div><div class="history-day-date">Hier</div></div>
            <div class="history-day-item"><div class="history-day-pill current">${d.redox_val}</div><div class="history-day-date">Auj.</div></div>
          </div>
        </div>

        <!-- Historique Temp Eau 7 jours -->
        <div class="card-subblock history-section">
          <div class="history-title">Température de l'eau sur les 7 derniers jours</div>
          <div class="history-days-row">
            <div class="history-day-item"><div class="history-day-pill">29° ↘</div><div class="history-day-date">J-6</div></div>
            <div class="history-day-item"><div class="history-day-pill">29° ↘</div><div class="history-day-date">J-5</div></div>
            <div class="history-day-item"><div class="history-day-pill">28° ↘</div><div class="history-day-date">J-4</div></div>
            <div class="history-day-item"><div class="history-day-pill">28° ↗</div><div class="history-day-date">J-3</div></div>
            <div class="history-day-item"><div class="history-day-pill">29° ↗</div><div class="history-day-date">J-2</div></div>
            <div class="history-day-item"><div class="history-day-pill">29° ↘</div><div class="history-day-date">Hier</div></div>
            <div class="history-day-item"><div class="history-day-pill current">${d.water_temp}°</div><div class="history-day-date">Auj.</div></div>
          </div>
        </div>

        <!-- Prévision Météo 4 Jours -->
        <div class="card-subblock" style="display: flex; justify-content: space-between; align-items: center;">
          <div style="text-align: center; flex: 1;">
            <div style="font-size: 16px;">☀️</div>
            <div style="font-size: 10px; font-weight: 700; color: #475569; margin-top: 2px;">25 | 36°</div>
          </div>
          <div style="height: 24px; width: 1px; background: #e2e8f0;"></div>
          <div style="text-align: center; flex: 1;">
            <div style="font-size: 16px;">☀️</div>
            <div style="font-size: 10px; font-weight: 700; color: #475569; margin-top: 2px;">21 | 34°</div>
          </div>
          <div style="height: 24px; width: 1px; background: #e2e8f0;"></div>
          <div style="text-align: center; flex: 1;">
            <div style="font-size: 16px;">⛅</div>
            <div style="font-size: 10px; font-weight: 700; color: #475569; margin-top: 2px;">20 | 38°</div>
          </div>
          <div style="height: 24px; width: 1px; background: #e2e8f0;"></div>
          <div style="text-align: center; flex: 1;">
            <div style="font-size: 16px;">☀️</div>
            <div style="font-size: 10px; font-weight: 700; color: #475569; margin-top: 2px;">22 | 39°</div>
          </div>
        </div>
      </div>

      <!-- BAS DEGRADE SYNTHESE -->
      <div class="domolink_pool-bottom-gradient">
        <div style="display: flex; justify-content: space-around; align-items: flex-end; padding: 6px 0;">
          <div style="text-align: center; flex: 1;">
            <div style="font-size: 14px; opacity: 0.9;">eau</div>
            <div style="font-size: 32px; font-weight: 700;">${d.water_temp}°C</div>
          </div>
          <div style="text-align: center; flex: 1;">
            <div style="font-size: 14px; opacity: 0.9;">pH</div>
            <div style="font-size: 26px; font-weight: 700;">${d.ph_val}</div>
          </div>
          <div style="text-align: center; flex: 1;">
            <div style="font-size: 14px; opacity: 0.9;">Chlore</div>
            <div style="font-size: 20px; font-weight: 700;">${d.cl_status}</div>
          </div>
        </div>

        <div class="card-footer-nav">
          <div style="text-align: center;">
            <div style="font-size: 18px;">〰️</div>
            <div>Menu</div>
          </div>
          <div class="dolphin-btn">🐬</div>
          <div style="text-align: center;">
            <div style="font-size: 18px;">🪣</div>
            <div>DomoLink Pool Control Store</div>
          </div>
        </div>
      </div>
    `;
  }

  _renderAdviceSection(d) {
    const ph = parseFloat(d.ph_val) || 7.2;
    const lsi = d.lsi_val;
    const lsi_cursor_pct = Math.max(0, Math.min(100, ((lsi + 1.0) / 2.0) * 100));

    let phTagClass = "tag-ok";
    let phActionText = "Le pH de l'eau est dans la zone idéale (7.2 - 7.4). L'action des désinfectants est optimale.";
    if (ph > 7.5) {
      phTagClass = "tag-danger";
      phActionText = `Le pH est trop élevé. L'eau risque d'entartrer les équipements et l'efficacité du chlore chute. ${
        d.ph_minus_dose > 0 ? `<br>👉 <span class="dose-highlight">Ajoutez ${d.ph_minus_dose}g de réducteur de pH (pH-)</span> dans le bassin filtration en marche.` : ""
      }`;
    } else if (ph < 7.1) {
      phTagClass = "tag-warn";
      phActionText = `Le pH est trop bas. L'eau est corrosive pour les joints et irritante. ${
        d.ph_plus_dose > 0 ? `<br>👉 <span class="dose-highlight">Ajoutez ${d.ph_plus_dose}g d'augmentateur de pH (pH+)</span>.` : ""
      }`;
    }

    const rx = parseFloat(d.redox_val) || 650;
    let rxTagClass = "tag-ok";
    let rxActionText = "Le potentiel d'oxydo-réduction assure une désinfection bactérienne et algicide parfaite.";
    if (rx < 600) {
      rxTagClass = "tag-danger";
      rxActionText = `Le pouvoir désinfectant est insuffisant. Risque d'eau trouble ou d'apparition d'algues. ${
        d.cl_shock_dose > 0 ? `<br>⚡ <span class="dose-highlight">Traitement Choc recommandé : ${d.cl_shock_dose}g</span>.` : ""
      }`;
    } else if (rx > 780) {
      rxTagClass = "tag-warn";
      rxActionText = "Le pouvoir désinfectant est très élevé. Réduisez la production d'électrolyse ou les ajouts de chlore.";
    }

    return `
      <!-- 1. REGULATION DU PH -->
      <div class="advice-card">
        <div class="advice-card-header">
          <div class="advice-card-title">
            <span>🧪</span> Régulation du pH
          </div>
          <div class="badge-status-tag ${phTagClass}">${d.ph_status}</div>
        </div>
        <div class="advice-metric-row">
          <div class="metric-box">
            <div class="metric-label">pH Actuel</div>
            <div class="metric-val" style="color: #0284c7;">${d.ph_val}</div>
            <div class="metric-target">Cible : 7.2 - 7.4</div>
          </div>
          <div class="metric-box">
            <div class="metric-label">Correction pH-</div>
            <div class="metric-val" style="color: #dc2626;">${d.ph_minus_dose}g</div>
            <div class="metric-target">Bisulfate sodique</div>
          </div>
          <div class="metric-box">
            <div class="metric-label">Correction pH+</div>
            <div class="metric-val" style="color: #2563eb;">${d.ph_plus_dose}g</div>
            <div class="metric-target">Carbonate sodique</div>
          </div>
        </div>
        <div class="advice-action-box">
          <div class="action-icon">💡</div>
          <div>${phActionText}</div>
        </div>
      </div>

      <!-- 2. DESINFECTION & CHLORE / REDOX -->
      <div class="advice-card">
        <div class="advice-card-header">
          <div class="advice-card-title">
            <span>⚡</span> Désinfection & Chlore
          </div>
          <div class="badge-status-tag ${rxTagClass}">${d.cl_status}</div>
        </div>
        <div class="advice-metric-row">
          <div class="metric-box">
            <div class="metric-label">Redox (ORP)</div>
            <div class="metric-val" style="color: #0284c7;">${d.redox_val} mV</div>
            <div class="metric-target">Cible : 650 - 750 mV</div>
          </div>
          <div class="metric-box">
            <div class="metric-label">Chlore Libre Estimé</div>
            <div class="metric-val" style="color: #16a34a;">${d.free_cl} ppm</div>
            <div class="metric-target">Recommandé : 1.0 - 2.0</div>
          </div>
          <div class="metric-box">
            <div class="metric-label">Chlore Actif (HOCl)</div>
            <div class="metric-val" style="color: #d97706;">${d.active_cl} ppm</div>
            <div class="metric-target">Désinfectant réel</div>
          </div>
        </div>
        <div class="advice-action-box">
          <div class="action-icon">🛡️</div>
          <div>${rxActionText}</div>
        </div>
      </div>

      <!-- 3. EQUILIBRE DE L'EAU (LSI / LANGELIER) -->
      <div class="advice-card">
        <div class="advice-card-header">
          <div class="advice-card-title">
            <span>⚖️</span> Équilibre de l'eau (LSI)
          </div>
          <div class="badge-status-tag ${Math.abs(lsi) < 0.3 ? "tag-ok" : "tag-warn"}">${d.lsi_status}</div>
        </div>
        <div class="lsi-bar-wrapper">
          <div class="lsi-gradient-bar">
            <div class="lsi-cursor" style="left: ${lsi_cursor_pct}%;"></div>
          </div>
          <div class="lsi-labels-row">
            <span>Corrosive (-1.0)</span>
            <span style="color: #16a34a; font-weight: bold;">Équilibrée (0.0)</span>
            <span>Entartrante (+1.0)</span>
          </div>
        </div>
        <div class="advice-action-box" style="margin-top: 14px;">
          <div class="action-icon">📘</div>
          <div>
            <strong>Indice LSI : ${lsi > 0 ? "+" : ""}${lsi}</strong> — 
            ${
              Math.abs(lsi) <= 0.3
                ? "Votre eau est parfaitement équilibrée. Le liner, la tuyauterie et les sondes de mesure sont préservés."
                : lsi > 0.3
                ? "L'eau a tendance à précipiter le calcaire (risque de dépôts blanchâtres sur la ligne d'eau et dans le filtre)."
                : "L'eau est corrosive et agressive pour les éléments métalliques et les joints."
            }
          </div>
        </div>
      </div>

      <!-- 4. GESTION DE LA FILTRATION -->
      <div class="advice-card">
        <div class="advice-card-header">
          <div class="advice-card-title">
            <span>⏱️</span> Optimisation Filtration
          </div>
          <div class="badge-status-tag tag-info">${d.pump_state === "on" ? "En marche" : "À l'arrêt"}</div>
        </div>
        <div class="advice-action-box">
          <div class="action-icon">🏊</div>
          <div>
            <strong>Recommandation :</strong> ${d.advice_filtration}.<br>
            <em>Règle d'or :</em> Filtrez en journée pendant les heures les plus chaudes et d'ensoleillement pour une efficacité maximale contre la photosynthèse des algues.
          </div>
        </div>
      </div>
    `;
  }

  _bindCardEvents(cardEl, d) {
    const btnAnalyse = cardEl.querySelector("#tab-btn-analyse");
    const btnControle = cardEl.querySelector("#tab-btn-controle");
    const btnPump = cardEl.querySelector("#btn-toggle-pump");

    if (btnAnalyse) {
      btnAnalyse.addEventListener("click", () => {
        this._view = "analyse";
        this._updateData();
      });
    }

    if (btnControle) {
      btnControle.addEventListener("click", () => {
        this._view = "controle";
        this._updateData();
      });
    }

    // Tous les boutons Marche/Arrêt de la pompe
    const btnPumps = cardEl.querySelectorAll("#btn-toggle-pump");
    btnPumps.forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        if (d.pump_entity_key && this._hass) {
          const isCurrentlyOn = btn.classList.contains("pump-on");
          btn.classList.toggle("pump-on", !isCurrentlyOn);
          btn.classList.toggle("pump-off", isCurrentlyOn);
          this._hass.callService("homeassistant", "toggle", {
            entity_id: d.pump_entity_key,
          });
        }
      });
    });
  }
}

/* =========================================================================
 * 🎆 SOCRATE RULES - EASTER EGG MODULE
 * ========================================================================= */
function launchSocrateRulesEasterEgg(targetRoot) {
  if (targetRoot.getElementById?.("socrate-rules-overlay") || targetRoot.querySelector?.("#socrate-rules-overlay")) return;

  // 1. Inject fonts in document head if not present
  if (!document.getElementById("socrate-rules-fonts")) {
    const fontLink = document.createElement("link");
    fontLink.id = "socrate-rules-fonts";
    fontLink.rel = "stylesheet";
    fontLink.href = "https://fonts.googleapis.com/css2?family=Orbitron:wght@500;900&family=Poppins:wght@300;600&display=swap";
    document.head.appendChild(fontLink);
  }

  // 2. Create fullscreen overlay
  const overlay = document.createElement("div");
  overlay.id = "socrate-rules-overlay";
  overlay.innerHTML = `
    <style>
      #socrate-rules-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        z-index: 999999;
        background-color: #030008;
        font-family: 'Poppins', sans-serif;
        display: flex;
        justify-content: center;
        align-items: center;
        overflow: hidden;
        user-select: none;
        -webkit-user-select: none;
        opacity: 0;
        transition: opacity 0.35s ease, transform 0.35s ease;
      }
      #socrate-rules-overlay * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        user-select: none;
        -webkit-user-select: none;
      }
      #socrate-rules-overlay canvas {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 1;
        pointer-events: none;
      }
      #socrate-rules-overlay .socrate-container {
        position: relative;
        z-index: 10;
        text-align: center;
        pointer-events: auto;
      }
      #socrate-rules-overlay h1.socrate-title {
        font-family: 'Orbitron', sans-serif;
        font-size: 6.5rem;
        font-weight: 900;
        letter-spacing: 12px;
        text-transform: uppercase;
        display: inline-block;
        line-height: 1.1;
        filter: 
          drop-shadow(0px 1px 0px #990066)
          drop-shadow(0px 2px 0px #660066)
          drop-shadow(0px 3px 0px #330066)
          drop-shadow(0px 4px 0px #1a0033)
          drop-shadow(0px 12px 15px rgba(0,0,0,0.9))
          drop-shadow(0 0 25px rgba(127, 0, 255, 0.6));
        transition: transform 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275), filter 0.5s;
        cursor: pointer;
      }
      #socrate-rules-overlay h1.socrate-title:hover {
        transform: scale(1.05);
        filter: 
          drop-shadow(0px 1px 0px #ff007f)
          drop-shadow(0px 2px 0px #990066)
          drop-shadow(0px 3px 0px #660066)
          drop-shadow(0px 4px 0px #330066)
          drop-shadow(0px 5px 0px #1a0033)
          drop-shadow(0px 15px 20px rgba(0,0,0,0.9))
          drop-shadow(0 0 40px rgba(0, 240, 255, 0.9));
      }
      #socrate-rules-overlay .socrate-letter {
        display: inline-block;
        background: linear-gradient(
          to bottom,
          #ff66b3 0%,
          #ff007f 35%,
          #7f00ff 65%,
          #00f0ff 100%
        );
        background-size: 100% 100%;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        animation: socrate-wave 1.6s ease-in-out infinite;
      }
      #socrate-rules-overlay p.socrate-sub {
        font-size: 1.1rem;
        color: rgba(255, 255, 255, 0.6);
        margin-top: 30px;
        letter-spacing: 4px;
        text-transform: uppercase;
        font-weight: 300;
        opacity: 0;
        animation: socrate-fadeIn 2s ease forwards 0.8s;
      }
      #socrate-rules-overlay p.socrate-sub strong {
        color: #00f0ff;
        font-weight: 600;
        text-shadow: 0 0 10px rgba(0, 240, 255, 0.5);
      }
      #socrate-rules-overlay p.socrate-exit-hint {
        font-size: 0.95rem;
        color: rgba(255, 255, 255, 0.6);
        margin-top: 16px;
        letter-spacing: 2px;
        text-transform: uppercase;
        font-weight: 300;
        opacity: 0;
        animation: socrate-fadeIn 2s ease forwards 1.1s;
        cursor: pointer;
      }
      #socrate-rules-overlay p.socrate-exit-hint strong {
        color: #ff007f;
        font-weight: 700;
        text-shadow: 0 0 10px rgba(255, 0, 127, 0.6);
      }
      #socrate-rules-overlay .socrate-instructions {
        position: absolute;
        bottom: 40px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 10;
        color: rgba(255, 255, 255, 0.4);
        font-size: 0.8rem;
        letter-spacing: 2px;
        text-transform: uppercase;
        pointer-events: none;
        animation: socrate-pulse 2s infinite;
        text-align: center;
        white-space: nowrap;
      }
      @keyframes socrate-wave {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-25px); }
      }
      @keyframes socrate-fadeIn {
        to { opacity: 1; transform: translateY(0); }
      }
      @keyframes socrate-pulse {
        0%, 100% { opacity: 0.3; }
        50% { opacity: 0.8; }
      }
      @media (max-width: 768px) {
        #socrate-rules-overlay h1.socrate-title {
          font-size: 3rem;
          letter-spacing: 6px;
        }
        #socrate-rules-overlay p.socrate-sub {
          font-size: 0.85rem;
          letter-spacing: 2px;
        }
        #socrate-rules-overlay p.socrate-exit-hint {
          font-size: 0.75rem;
          letter-spacing: 1px;
        }
      }
    </style>
    <canvas id="socrateParticleCanvas"></canvas>
    <div class="socrate-container">
      <h1 class="socrate-title" id="socrateTitle">Socrate Rules</h1>
      <p class="socrate-sub" id="socrateSub">Une expérience visuelle <strong>hautement philosophique</strong>.</p>
      <p class="socrate-exit-hint" id="socrateExitHint">Cliquez 3 fois sur <strong>SOCRATE RULES</strong> pour quitter</p>
    </div>
    <div class="socrate-instructions" id="socrateInstructions">Bougez votre souris & cliquez n'importe où</div>
  `;

  targetRoot.appendChild(overlay);

  // Localize easter egg strings if host has translation helper
  const host = targetRoot.host || (targetRoot instanceof HTMLElement ? targetRoot : null);
  if (host && typeof host.t === "function") {
    const subEl = overlay.querySelector("#socrateSub");
    const hintEl = overlay.querySelector("#socrateExitHint");
    const instEl = overlay.querySelector("#socrateInstructions");
    if (subEl) subEl.innerHTML = host.t("easter_egg_sub");
    if (hintEl) hintEl.textContent = host.t("easter_egg_hint");
    if (instEl) instEl.textContent = host.t("easter_egg_instructions");
  }

  // Fade in animation
  requestAnimationFrame(() => {
    overlay.style.opacity = "1";
  });

  const canvas = overlay.querySelector("#socrateParticleCanvas");
  const ctx = canvas.getContext("2d");
  const title = overlay.querySelector("#socrateTitle");
  const TWO_PI = Math.PI * 2;

  // Wave letter splitting
  const lines = ["Socrate", "Rules"];
  title.innerHTML = "";
  let globalCharIndex = 0;
  lines.forEach((lineText) => {
    const lineDiv = document.createElement("div");
    lineDiv.style.display = "block";
    [...lineText].forEach((char) => {
      const span = document.createElement("span");
      if (char === " ") {
        span.innerHTML = "&nbsp;";
      } else {
        span.textContent = char;
      }
      span.classList.add("socrate-letter");
      span.style.animationDelay = `${globalCharIndex * 0.07}s`;
      lineDiv.appendChild(span);
      globalCharIndex++;
    });
    title.appendChild(lineDiv);
  });

  // Particles system
  let particlesArray = [];
  let sparksArray = [];
  let animId = null;
  let isClosing = false;

  let mouse = {
    x: null,
    y: null,
    radius: 150,
    radiusSq: 22500,
  };

  function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  resizeCanvas();

  class Particle {
    constructor(x, y, directionX, directionY, size, color) {
      this.x = x;
      this.y = y;
      this.directionX = directionX;
      this.directionY = directionY;
      this.size = size;
      this.color = color;
      this.originalSize = size;
    }

    draw() {
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.size, 0, TWO_PI, false);
      ctx.fillStyle = this.color;
      ctx.fill();
    }

    update() {
      if (this.x > canvas.width || this.x < 0) this.directionX = -this.directionX;
      if (this.y > canvas.height || this.y < 0) this.directionY = -this.directionY;
      this.x += this.directionX;
      this.y += this.directionY;

      if (mouse.x != null && mouse.y != null) {
        let dx = mouse.x - this.x;
        let dy = mouse.y - this.y;
        let distanceSq = dx * dx + dy * dy;
        if (distanceSq < mouse.radiusSq) {
          let distance = Math.sqrt(distanceSq);
          let forceDirectionX = dx / distance;
          let forceDirectionY = dy / distance;
          let force = (mouse.radius - distance) / mouse.radius;
          this.x -= forceDirectionX * force * 3;
          this.y -= forceDirectionY * force * 3;
          if (this.size < this.originalSize * 3.5) this.size += 0.2;
        } else if (this.size > this.originalSize) {
          this.size -= 0.1;
        }
      } else if (this.size > this.originalSize) {
        this.size -= 0.1;
      }
      this.draw();
    }
  }

  class Spark {
    constructor(x, y) {
      this.x = x;
      this.y = y;
      this.size = Math.random() * 6 + 2;
      this.speedX = (Math.random() - 0.5) * 12;
      this.speedY = (Math.random() - 0.5) * 12;
      const colors = ["#ff007f", "#7f00ff", "#00f0ff", "#ffffff"];
      this.color = colors[Math.floor(Math.random() * colors.length)];
      this.alpha = 1;
      this.decay = Math.random() * 0.015 + 0.01;
    }

    update() {
      this.x += this.speedX;
      this.y += this.speedY;
      this.speedX *= 0.98;
      this.speedY *= 0.98;
      this.alpha -= this.decay;
      if (this.alpha > 0) {
        ctx.save();
        ctx.globalAlpha = this.alpha;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, TWO_PI);
        ctx.fillStyle = this.color;
        ctx.shadowBlur = 15;
        ctx.shadowColor = this.color;
        ctx.fill();
        ctx.restore();
      }
    }
  }

  function initParticles() {
    particlesArray = [];
    let baseParticles = (canvas.width * canvas.height) / 9000;
    let numberOfParticles = Math.min(baseParticles, 250);
    for (let i = 0; i < numberOfParticles; i++) {
      let size = Math.random() * 2 + 0.5;
      let x = Math.random() * (canvas.width - size * 4) + size * 2;
      let y = Math.random() * (canvas.height - size * 4) + size * 2;
      let directionX = Math.random() * 0.4 - 0.2;
      let directionY = Math.random() * 0.4 - 0.2;
      let colorPalette = ["rgba(127, 0, 255, 0.4)", "rgba(0, 240, 255, 0.3)", "rgba(255, 0, 127, 0.3)"];
      let color = colorPalette[Math.floor(Math.random() * colorPalette.length)];
      particlesArray.push(new Particle(x, y, directionX, directionY, size, color));
    }
  }

  function connectParticles() {
    let maxDistance = 120;
    let maxDistanceSq = maxDistance * maxDistance;
    for (let a = 0; a < particlesArray.length; a++) {
      for (let b = a + 1; b < particlesArray.length; b++) {
        let dx = particlesArray[a].x - particlesArray[b].x;
        let dy = particlesArray[a].y - particlesArray[b].y;
        let distanceSq = dx * dx + dy * dy;
        if (distanceSq < maxDistanceSq) {
          let distance = Math.sqrt(distanceSq);
          let opacity = (1 - distance / maxDistance) * 0.15;
          ctx.strokeStyle = `rgba(127, 0, 255, ${opacity})`;
          ctx.lineWidth = 0.5;
          ctx.beginPath();
          ctx.moveTo(particlesArray[a].x, particlesArray[a].y);
          ctx.lineTo(particlesArray[b].x, particlesArray[b].y);
          ctx.stroke();
        }
      }
    }
  }

  function animate() {
    ctx.fillStyle = "rgba(3, 0, 8, 0.15)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    for (let i = 0; i < particlesArray.length; i++) {
      particlesArray[i].update();
    }

    for (let i = sparksArray.length - 1; i >= 0; i--) {
      sparksArray[i].update();
      if (sparksArray[i].alpha <= 0) {
        sparksArray.splice(i, 1);
      }
    }

    connectParticles();
    animId = requestAnimationFrame(animate);
  }

  // Mouse & Touch events
  function onMouseMove(e) {
    mouse.x = e.clientX;
    mouse.y = e.clientY;
  }
  function onMouseOut() {
    mouse.x = null;
    mouse.y = null;
  }
  function onTouchMove(e) {
    if (e.touches && e.touches.length > 0) {
      mouse.x = e.touches[0].clientX;
      mouse.y = e.touches[0].clientY;
    }
  }
  function onTouchEnd() {
    mouse.x = null;
    mouse.y = null;
  }
  function onOverlayClick(e) {
    const x = e.clientX || window.innerWidth / 2;
    const y = e.clientY || window.innerHeight / 2;
    for (let i = 0; i < 30; i++) {
      sparksArray.push(new Spark(x, y));
    }
  }
  function onKeyDown(e) {
    if (e.key === "Escape") {
      cleanup();
    }
  }

  window.addEventListener("resize", resizeCanvas);
  window.addEventListener("mousemove", onMouseMove);
  window.addEventListener("mouseout", onMouseOut);
  window.addEventListener("touchmove", onTouchMove, { passive: true });
  window.addEventListener("touchend", onTouchEnd, { passive: true });
  window.addEventListener("keydown", onKeyDown);
  overlay.addEventListener("click", onOverlayClick);

  // Exit trigger: 3 clicks in < 2s on "SOCRATE RULES"
  let exitClicks = [];
  function handleExitClick(clientX, clientY) {
    if (isClosing) return;
    const now = Date.now();
    exitClicks = exitClicks.filter((t) => now - t < 2000);
    exitClicks.push(now);

    const x = clientX || window.innerWidth / 2;
    const y = clientY || window.innerHeight / 2;
    for (let i = 0; i < 70; i++) {
      sparksArray.push(new Spark(x, y));
    }

    if (exitClicks.length >= 3) {
      isClosing = true;
      exitClicks = [];
      for (let i = 0; i < 150; i++) {
        sparksArray.push(new Spark(window.innerWidth / 2, window.innerHeight / 2));
      }
      overlay.style.transition = "opacity 0.38s ease, transform 0.38s ease";
      overlay.style.opacity = "0";
      overlay.style.transform = "scale(1.05)";
      setTimeout(() => {
        cleanup();
      }, 360);
    }
  }

  title.addEventListener("click", (e) => {
    e.stopPropagation();
    handleExitClick(e.clientX, e.clientY);
  });
  title.addEventListener(
    "touchstart",
    (e) => {
      e.stopPropagation();
      const touch = e.touches && e.touches[0];
      handleExitClick(touch ? touch.clientX : null, touch ? touch.clientY : null);
    },
    { passive: true }
  );

  const exitHint = overlay.querySelector("#socrateExitHint");
  if (exitHint) {
    exitHint.addEventListener("click", (e) => {
      e.stopPropagation();
      handleExitClick(e.clientX, e.clientY);
    });
    exitHint.addEventListener(
      "touchstart",
      (e) => {
        e.stopPropagation();
        const touch = e.touches && e.touches[0];
        handleExitClick(touch ? touch.clientX : null, touch ? touch.clientY : null);
      },
      { passive: true }
    );
  }

  function cleanup() {
    if (animId) {
      cancelAnimationFrame(animId);
      animId = null;
    }
    window.removeEventListener("resize", resizeCanvas);
    window.removeEventListener("mousemove", onMouseMove);
    window.removeEventListener("mouseout", onMouseOut);
    window.removeEventListener("touchmove", onTouchMove);
    window.removeEventListener("touchend", onTouchEnd);
    window.removeEventListener("keydown", onKeyDown);
    if (overlay.parentNode) {
      overlay.parentNode.removeChild(overlay);
    }
  }

  initParticles();
  animate();
}

if (!customElements.get("domolink-pool-panel")) {
  customElements.define("domolink-pool-panel", DomoLinkPoolControlPanel);
}
if (!customElements.get("domolink_pool-panel")) {
  customElements.define("domolink_pool-panel", DomoLinkPoolControlPanel);
}
